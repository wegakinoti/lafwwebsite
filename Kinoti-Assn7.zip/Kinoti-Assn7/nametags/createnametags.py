print("***Entering createnametags***")
# script to create nametas html file
htmlheader8 = '''
    <!DOCTYPE html>
<!--
	Name: Wega Kinoti
	Assignment: 7
	Created: November 4, 2019
	Description: NameTags8 Page
-->
<html>
    <head>
        <title>
            Name Tags 8
        </title>
        <meta charset="UTF-8">
        <meta name="description" content="name tags 8 page">
        <meta name="keywords" content="HTML,CSS, JavaScript">
        <meta name="author" content="Wega Kinoti">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="css/nametags8.css">
    </head>
    '''

htmlheader10 = '''
    <!DOCTYPE html>
<!--
	Name: Wega Kinoti
	Assignment: 7
	Created: November 4, 2019
	Description: NameTags10 Page
-->
<html>
    <head>
        <title>
            Name Tags 10
        </title>
        <meta charset="UTF-8">
        <meta name="description" content="name tags 10 page">
        <meta name="keywords" content="HTML,CSS, JavaScript">
        <meta name="author" content="Wega Kinoti">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="css/nametags10.css">
    </head>
    '''
csvFile = open('registrant_data.csv', 'r')


def createNametags8():
    print('** entering createnametags8 function **')
    tags8 = open('../nametags8gen.html', 'w')
    tags8.write(htmlheader8)
    tags8.write('<body>\n')
    count = 0

    registrants = csvFile.readlines()

    for registrants in registrants:
        registrants = registrants.split(",")
        count += 1
        if count % 2 == 1:
            tags8.write('\t<div class ="row"> \n')
            tags8.write('\t\t<div class ="left"> \n')
            tags8.write('\t\t\t\t <p class ="firstname">' + registrants[2] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="lastname">' + registrants[3] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="position">' + registrants[12] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="company">' + registrants[13] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="location">' + registrants[6] + '</p>\n')
            tags8.write('\t\t</div>\n')
        else:
            tags8.write('\t\t<div class ="right"> \n')
            tags8.write('\t\t\t\t <p class ="firstname">' + registrants[2] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="lastname">' + registrants[3] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="position">' + registrants[12] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="company">' + registrants[13] + '</p>\n')
            tags8.write('\t\t\t\t <p class ="location">' + registrants[6] + '</p>\n')
            tags8.write('\t\t</div>\n')
            tags8.write('\t</div> \n')

    tags8.write('</body>\n')
    tags8.write('</html>')
    tags8.close()
    csvFile.close()
    print('** exiting createnametags8 function **')


csvFile1 = open('registrant_data.csv', 'r')
def createNametags10():
    print('** entering createnametags10 function **')
    tags10 = open('../nametags10gen.html', 'w')
    tags10.write(htmlheader10)
    tags10.write('<body>\n')
    count = 0
    registrants = csvFile1.readlines()

    for registrants in registrants:
        registrants = registrants.split(",")
        count += 1
        if count % 2 == 1:
            tags10.write('\t<div class ="container"> \n')
            tags10.write('\t\t<div class ="left"> \n')
            tags10.write('\t\t\t\t<p class ="name">' + registrants[2] + " " + registrants[3] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="position">' + registrants[12] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="company">' + registrants[13] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="location">' + registrants[6] + '</p>\n')
            tags10.write('\t\t</div>\n')
        else:
            tags10.write('\t\t<div class ="right"> \n')
            tags10.write('\t\t\t\t<p class ="name">' + registrants[2] + " " + registrants[3] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="position">' + registrants[12] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="company">' + registrants[13] + '</p>\n')
            tags10.write('\t\t\t\t<p class ="location">' + registrants[6] + '</p>\n')
            tags10.write('\t\t</div>\n')
            tags10.write('\t</div> \n')

    tags10.write('</body>\n')
    tags10.write('</html>')
    tags10.close()
    print('** exiting createnametags10 function **')



createNametags8()
createNametags10()
csvFile.close()
print("***Exiting createnametags***")
