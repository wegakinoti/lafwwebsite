function checkVotes(){
//document.cookie = "vote0=JordynWoods";

    //try hardcoading some cookie values

    var nominees = document.getElementsByName("nominees");
    for (var i = 0; i < nominees.length; i++){
        if(nominees[i].checked){
            var name = nominees[i].id;
            var vote = getVote(name);
            vote++;
            setVotes(name, vote);

            document.getElementById("vote").innerHTML = "" + vote;
            return true;
        }
    }
    return false;
}

function setVotes(key, value) {
    document.cookie = key + "=" + value;
}

function getVote(key){//this doesn't work, ask whats wrong
   var cookies = document.cookie;
   var cookieArray = cookies.split(";");
   for(var i = 0; i < cookieArray.length; i++){
       var nameValue = cookieArray[i].split("=");
       if(nameValue.length == 2){
           var name = nameValue[0].trim();
           var value = nameValue[1].trim();
           if (key == name){
               return parseInt(value);
           }
       }

   }
   return 0;
}






/*
function checkVotes(){
    document.cookie = "Testcookie = Testvalue";
    document.cookie = "Testcookie2 = Testvalue2";
    if (nominees[0].checked){
        //bump the value
        var cookies = document.cookie;
        var cookieArray = cookies.split(";");
        var length = cookieArray.length;

        for (var i = 0; i < length; i++){
            //alert("coockie " + cookieArray[i]);
            var keyValue = cookieArray[i].split("=");
            alert("Key: " + keyValue[0] + " Value: " + keyValue[1]);

            if(keyValueArray[0]=="vote1"){
                var votes= parseInt(keyValue[1]);
                votes++;
            }

        }


    }
     Old Way of checking for votes, outdated because it doesn't store it as a cookie which is better
     const vote1 = document.getElementById("vote1");
     if (vote1.checked){
         alert("Thank you for selecting " + vote1.value);
         return true;
     }

     const vote2 = document.getElementById("vote2");
     if (vote2.checked){
         alert("Thank you for selecting " + vote2.value);
         return true;
     }

     const vote3 = document.getElementById("vote3");
     if (vote3.checked){
         alert("Thank you for selecting " +vote3.value);
         return true;
     }
    */